<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\MenuConstructorController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
//pages
Route::get('/', function () {return view('index');});
Route::get('/menu', function () {return view('menu');});
Route::get('/receips', function () {return view('receips');});
Route::get('/articles', function () {return view('articles');});
Route::get('/profile', function () {return view('profile');});
//reg and auth
Route::get('/', [AuthController::class, 'index'])->name('index');
Route::get('/register', [AuthController::class, 'showRegistrationForm'])->name('register');
Route::post('/register', [AuthController::class, 'register']);
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
//menu-constructor
// routes/web.php
Route::get('/menu-builder', [MenuConstructorController::class, 'showForm'])->middleware('auth');
Route::post('/menu-builder', [MenuConstructorController::class, 'calculate'])->middleware('auth');


