<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\RecipeController;
use App\Http\Controllers\MenuConstructorController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
//pages
Route::get('/', function () {return view('index');});
Route::get('/menu', function () {return view('menu');});
// Route::get('/recipes', function () {return view('recipes');});
Route::get('/articles', function () {return view('articles');});
Route::get('/profile', function () {return view('profile');});
//reg and auth
Route::get('/', [AuthController::class, 'index'])->name('index');
Route::get('/register', [AuthController::class, 'showRegistrationForm'])->name('register');
Route::post('/register', [AuthController::class, 'register']);
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
//menu-constructor
Route::get('/menu-builder', [MenuConstructorController::class, 'showForm'])->middleware('auth');
Route::post('/menu-builder', [MenuConstructorController::class, 'calculate'])->middleware('auth');
//recipes
Route::get('/recipes', [RecipeController::class, 'index'])->name('recipes.index');
Route::get('/recipes/{id}', [RecipeController::class, 'show'])->name('recipes.show');



