<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\RecipeController;
use App\Http\Controllers\Admin\RecipeAdminController;
use App\Http\Controllers\Admin\PostAdminController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
//pages
// Route::get('/', function () {return view('index');});
Route::get('/menu', function () {return view('menu');});
Route::get('/recipes', [ RecipeController::class, 'index'])->name('recipes');
Route::get('/articles', function () {return view('articles');});
Route::get('/profile', function () {return view('profile');});
//reg and auth
Route::get('/', [AuthController::class, 'index'])->name('index');
Route::get('/register', [AuthController::class, 'showRegistrationForm'])->name('register');
Route::post('/register', [AuthController::class, 'register']);
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

Route::middleware(['auth', 'admin'])->group(function () {
    // Рецепты
    Route::get('/admin/recipes', [ RecipeAdminController::class, 'index'])->name('admin.recipesAdmin');
    Route::get('/admin/recipes/create', [RecipeAdminController::class, 'create'])->name('admin.createRecipe');
    Route::post('/admin/recipes', [RecipeAdminController::class, 'store'])->name('admin.store');
    Route::get('/admin/recipes/{id}/edit', [RecipeAdminController::class, 'edit'])->name('admin.editRecipe');
    Route::put('/admin/recipes/{id}', [RecipeAdminController::class, 'update'])->name('admin.update');
    Route::delete('/admin/recipes/{id}', [RecipeAdminController::class, 'destroy'])->name('admin.destroy');

    // Статьи
    Route::get('/admin/posts', [PostAdminController::class, 'index'])->name('admin.postsAdmin');
    Route::get('/admin/posts/create', [PostAdminController::class, 'create'])->name('admin.createPost');
    Route::post('/admin/posts', [PostAdminController::class, 'store'])->name('admin.store');
    Route::get('/admin/posts/{id}/edit', [PostAdminController::class, 'edit'])->name('admin.editPost');
    Route::put('/admin/posts/{id}', [PostAdminController::class, 'update'])->name('admin.update');
    Route::delete('/admin/posts/{id}', [PostAdminController::class, 'destroy'])->name('admin.destroy');
});

