<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\Recipe;
use App\Models\Category;

class RecipeController extends Controller
{
   
    public function index(Request $request)
    {
        // Получаем все категории для фильтрации
        $categories = Category::all();
        // Получаем все рецепты с учетом фильтров
        $query = Recipe::query();
        // Фильтрация по названию
        if ($request->has('search') && $request->input('search') != '') {
            $query->where('name', 'like', '%' . $request->input('search') . '%');
        }
        // Фильтрация по калорийности
        if ($request->has('calories') && $request->input('calories') != '') {
            $query->where('calories', '<=', $request->input('calories'));
        }
        // Фильтрация по категории
        if ($request->has('category') && $request->input('category') != '') {
            $query->where('id_category', $request->input('category'));
        }
        $recipes = $query->paginate(10); // Пагинация для удобства
        return view('recipes.index', compact('recipes', 'categories'));
    }
 
    public function show($id)
    {
        $recipe = Recipe::findOrFail($id);
        return view('recipes.show', compact('recipe'));
    }
}
