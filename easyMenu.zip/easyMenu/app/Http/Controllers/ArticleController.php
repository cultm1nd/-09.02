<?php

namespace App\Http\Controllers;
use App\Models\Article;
use Illuminate\Http\Request;

class ArticleController extends Controller
{
    public function index()
    {
        // все статьи
        $posts = Article::all();

        // представление с переданными статьями
        return view('articles', compact('posts'));
    }
    public function showArticle($id)
{
    $post = Article::findOrFail($id);
    // dd($post);
    return view('showArticle', compact('post'));
}
}
