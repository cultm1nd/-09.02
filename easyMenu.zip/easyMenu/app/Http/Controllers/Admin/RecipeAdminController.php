<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Recipe;
use App\Models\Category;
use Illuminate\Http\Request;


class RecipeAdminController extends Controller
{
    public function indexRecipe()
    {
        $recipes = Recipe::all();
        return view('admin.recipesAdmin',["recipes"=>$recipes]);
    }

    public function createRecipe()
    {
        $categories = Category::all();
        return view('admin.createRecipe', compact('categories'));
    }

    public function storeRecipe(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'description' => 'required',
            'img' => 'required|image',
            'ingredients' => 'required',
            'calories' => 'required|numeric',
            'id_category' => 'required|exists:categories,id_category',
            'id_menu' => 'required|exists:menus,id_menu', 
        ]);

        $imgPath = $request->file('img')->store('images', 'public');

        Recipe::create([
            'name' => $request->name,
            'description' => $request->description,
            'img' => $imgPath,
            'ingredients' => $request->ingredients,
            'calories' => $request->calories,
            'id_category' => $request->id_category,
            'id_menu' => $request->id_menu, 

        ]);

        return redirect()->route('admin.recipesAdmin')->with('success', 'Рецепт добавлен!');
    }

    public function editRecipe($id)
    {
        $recipe = Recipe::findOrFail($id);
        $categories = Category::all();
        return view('admin.editRecipe', compact('recipe', 'categories'));
    }

    public function updateRecipe(Request $request, $id)
    {
        $request->validate([
            'name' => 'required',
            'description' => 'required',
            'img' => 'image',
            'ingredients' => 'required',
            'calories' => 'required|numeric',
            'id_category' => 'required|exists:categories,id_category',
            'id_menu' => 'required|exists:menus,id_menu', 
        ]);

        $recipe = Recipe::findOrFail($id);
        $recipe->name = $request->name;
        $recipe->description = $request->description;
        $recipe->ingredients = $request->ingredients;
        $recipe->calories = $request->calories;
        $recipe->id_category = $request->id_category;

        if ($request->hasFile('img')) {
            $imgPath = $request->file('img')->store('images', 'public');
            $recipe->img = $imgPath;
        }

        $recipe->save();

        return redirect()->route('admin.recipesAdmin')->with('success', 'Рецепт обновлен!');
    }

    public function destroyRecipe($id)
    {
        $recipe = Recipe::findOrFail($id);
        $recipe->delete();

        return redirect()->route('admin.recipesAdmin')->with('success', 'Рецепт удален!');
    }
}
