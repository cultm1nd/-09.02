<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;
use App\Models\Article;
use Illuminate\Http\Request;

class ArticleAdminController extends Controller
{
    public function indexArticle()
    {
        $posts = Article::all();
        return view('admin.articlesAdmin', compact('posts'));
    }

    public function createArticle()
    {
        return view('admin.createArticle');
    }

    public function storeArticle(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'content' => 'required|string',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048', // Валидация изображения
        ]);
    
        $post = new Article();
        $post->title = $request->input('title');
        $post->content = $request->input('content');
        $post->user_id = auth()->id(); // Убедитесь, что пользователь авторизован
    
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $imageName = time() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path('img'), $imageName);
            $post->image = $imageName;
        }
    
        $post->save();
    
        return redirect()->route('admin.articlesAdmin')->with('success', 'Статья успешно создана!');
    }
    

    public function editArticle($id)
    {
        $post = Article::findOrFail($id);
        return view('admin.editArticle', compact('post'));
    }

    public function updateArticle(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'content' => 'required|string',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048', // Валидация изображения
        ]);
    
        $post = Article::findOrFail($id);
        $post->title = $request->input('title');
        $post->content = $request->input('content');
    
        // Обработка загрузки изображения
        if ($request->hasFile('image')) {
            // Удаление старого изображения, если оно существует
            if ($post->image) {
                Storage::delete($post->image);
            }
    
            // Сохранение нового изображения
            $path = $request->file('image')->store('img', 'public');
            $post->image = $path; // Сохраняем путь к изображению в базе данных
        }
    
        $post->save();
    
        return redirect()->route('admin.articlesAdmin')->with('success', 'Статья успешно обновлена!');
    }

    public function destroyArticle($id)
    {
        $post = Article::findOrFail($id);
        $post->delete();

        return redirect()->route('admin.articlesAdmin')->with('success', 'Статья удалена!');
    }
}
