<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Post;
use Illuminate\Http\Request;

class PostAdminController extends Controller
{
    public function index()
    {
        $posts = Post::all();
        return view('admin.posts.postsAdmin', compact('posts'));
    }

    public function create()
    {
        return view('admin.posts.createPost');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'content' => 'required',
        ]);

        Post::create([
            'title' => $request->title,
            'content' => $request->content,
            'user_id' => auth()->id(),
        ]);

        return redirect()->route('admin.posts.postsAdmin')->with('success', 'Статья добавлена!');
    }

    public function edit($id)
    {
        $post = Post::findOrFail($id);
        return view('admin.posts.editPost', compact('post'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'title' => 'required',
            'content' => 'required',
        ]);

        $post = Post::findOrFail($id);
        $post->title = $request->title;
        $post->content = $request->content;
        $post->save();

        return redirect()->route('admin.posts.postsAdmin')->with('success', 'Статья обновлена!');
    }

    public function destroy($id)
    {
        $post = Post::findOrFail($id);
        $post->delete();

        return redirect()->route('admin.posts.postsAdmin')->with('success', 'Статья удалена!');
    }
}
