<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Models\User;

class AuthController extends Controller
{
    public function index()

    {
        return view('index');
    }
    public function showLoginForm()
    {
        return view('login');
    }
    public function login(Request $request)
    {
        $request->validate([
      'email' => 'required|email',
     'password' => 'required',
        ]);
        $credentials = $request->only('email', 'password');
        if (Auth::attempt($credentials)) {
            // Успешный вход
            return redirect('/')->with('success', 'Вы успешно вошли!');
        }
  return back()->withErrors(['email' => 'Неверные учетные данные.']);
 }

    public function showRegistrationForm()
    {
        return view('register');
    }

    public function register(Request $request)

    {
        $request->validate([
            'username' => 'required|string|max:255',
            'email' => 'required|email|unique:user',
            'password' => 'required|string|min:8|confirmed',
        ]);

        $user = User::create([
            'username' => $request->username,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'id_role' => 2,
        ]);

        Auth::login($user);
        return redirect('/')->with('success', 'Регистрация завершена, добро пожаловать!');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        return redirect('/')->with('success', 'Вы вышли из аккаунта.');
    }
}
