<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Models\User;

class AuthController extends Controller
{
    public function index() 
    { 
        return view('index'); 
    } 
    
    public function showLoginForm() 
    { 
        return view('login'); 
    } 
    
    public function login(Request $request) 
    { 
        // Валидация данных запроса
        $request->validate([ 
            'email' => 'required|email', 
            'password' => 'required', 
        ]); 
    
        $credentials = $request->only('email', 'password'); 
        
        // Проверка учетных данных
        if (Auth::attempt($credentials)) { 
            // Успешный вход
            $user = Auth::user();
            session("user",$user);
          
            return view('index',["user"=>$user]);
           //  return redirect('/')->with('success', 'Вы успешно вошли!'); 
        } 
        
        // Неверные учетные данные
       return back()->withErrors(['email' => 'Неверные учетные данные.']); 
    } 
    
    public function showRegistrationForm() 
    { 
        return view('register'); 
    } 
    
    public function register(Request $request)  
    {  
        // Валидация данных запроса 
        $request->validate([  
            'username' => 'required|string|max:255',  
            'email' => 'required|email|unique:users,email',  
            'login' => 'required|string|max:255|unique:users,login', // Добавлено поле логин
            'password' => 'required|string|min:8|confirmed',  
        ]);  
 
        // Создание нового пользователя 
        $user = User::create([  
            'username' => $request->username,  
            'email' => $request->email,  
            'login' => $request->login, // Не забудьте добавить значение логина
            'password' => Hash::make($request->password),  
            'id_role' => 2,  
        ]);  
 
        // Автоматический вход после регистрации 
        Auth::login($user);  
        return redirect('/')->with('success', 'Регистрация завершена, добро пожаловать!');  
    }  
    
    
    public function logout(Request $request) 
    { 
        Auth::logout(); 
        return redirect('/')->with('success', 'Вы вышли из аккаунта.'); 
    } 
    
}
