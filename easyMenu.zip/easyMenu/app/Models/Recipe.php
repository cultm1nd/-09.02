<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Recipe extends Model
{
    use HasFactory;

    protected $table = 'recipes';
    
    //первичный ключ
    protected $primaryKey = 'id_recipe';

    // массовое заполнение для указанных полей
    protected $fillable = [
        'name',
        'description',
        'image',
        'ingredients',
        'calories',
        'id_category',
    ];


    public function category()
    {
        return $this->belongsTo(Category::class, 'id_category', 'id_category');
    }
}
