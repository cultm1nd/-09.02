<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Database\Str;
use Illuminate\Support\Facades\DB;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // DB::table('user')->insert([
        // [
        //  'username'=>'user1',
        //  'email'=>'user1@mail.ru',
        //  'password'=>'12345',
        //  'login'=>'user1',
        //  'role'=>'user',
        //  'id_role'=>2
        // ],
        // [
        //  'username'=>'user1',
        //  'email'=>'user1@mail.ru',
        //  'password'=>'12345',
        //  'login'=>'user1',
        //  'role'=>'user',
        //  'id_role'=>2
        // ],
        // ]);
    }
}
