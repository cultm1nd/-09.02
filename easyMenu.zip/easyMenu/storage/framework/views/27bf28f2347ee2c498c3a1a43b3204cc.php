<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Главная страница - Планирование питания</title>

    <!-- Подключение CSS Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Ваши собственные стили -->
    <link rel="stylesheet" href="../asset/css/style.css">
    <style>
        .navbar-custom {
            background-color: #E43E4E; /* Ваш цвет */
        }
        .navbar-custom a {
            color:white;
        }
        .footer-custom
        {
            background-color:#E43E4E; /* Ваш цвет */
        }
        .nav-link{
           color:white;
        }
      
        h2 {
  display: flex;
  align-items: center;
  justify-content: center;
  color:#453E50;
}
h2 span {
  background: #fff;
  margin: 0 15px;
}
h2:before,
h2:after {
  background: #AECB6F;
  height: 2px;
  flex: 1;
  content: '';
}
h2.left:after {
  background: #AECB6F;
}
h2.right:before {
  background: #AECB6F;
}
.my-4
{
    color:#453E50;
}
.my-4 #online{
    text-align:center;
}
.navbar-brand
{
    color:white;
}

.custom-green-btn{
    background-color: #AECB6F;
    color:white;
}
a:link {color:white !important;}
a:hover {color:#453E50 !important;}
a:visited {color:white !important;}
.nav-item img{
    width:40px;
    height:40px;
    margin-right:30px;
}
    </style>
</head>
<body>
    <div class="container">
    <?php if(session('success')): ?>

<div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>  
   <nav class="navbar navbar-expand-lg navbar-light navbar-custom " > 
        <a href="/"><img src="<?php echo e(asset('img/logo.svg')); ?>" style="width:200px;height:200px; margin-right:100px;margin-left:20px"> </a>
    
    <a class="navbar-brand"  href="/">ГЛАВНАЯ</a> 
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> 
        <span class="navbar-toggler-icon"></span> 
    </button> 
    <div class="collapse navbar-collapse" id="navbarSupportedContent"> 

           <?php if($user->id_role == 1): ?>
           dfggfd
           <ul class="navbar-nav mr-auto" > 
               <li class="nav-item" > 
                   <a class="nav-link" href="/menu">КОНСТРУКТОР МЕНЮ</a> 
               </li> 
               <li class="nav-item"> 
                   <a class="nav-link" href="/admin/recipes">РЕЦЕПТЫ</a> 
               </li> 
               <li class="nav-item"> 
                   <a class="nav-link" href="/articles">СТАТЬИ</a> 
               </li> 
           </ul> 
           <?php else: ?>
           <ul class="navbar-nav mr-auto" > 
               <li class="nav-item" > 
                   <a class="nav-link" href="/menu">КОНСТРУКТОР МЕНЮ</a> 
               </li> 
               <li class="nav-item"> 
                   <a class="nav-link" href="/recipes">РЕЦЕПТЫ</a> 
               </li> 
               <li class="nav-item"> 
                   <a class="nav-link" href="/articles">СТАТЬИ</a> 
               </li> 
           </ul> 


        
        <?php endif; ?>
      
        
        <ul class="navbar-nav"> 
            <?php if(Auth::check()): ?> 
                <li class="nav-item"> 
                    <a class="nav-link" href="/profile"><img src="../img/user.png"> </a> 
                </li> 
                <li class="nav-item"> 
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none"> 
                        <?php echo csrf_field(); ?> 
                    </form> 
                    <a class="nav-link" href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Выход</a> 
                </li> 
            <?php else: ?> 
                <li class="nav-item"> 
                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><img  src="../img/user.png"> </a> 

                </li> 
                <!-- <li class="nav-item"> 
                    <a class="nav-link" href="/register">Регистрация</a> 
                </li>  -->
            <?php endif; ?> 
        </ul> 
    </div> 
</nav>

        <main class="my-4">
            <!-- <h2>Добро пожаловать!</h2> -->
            <h2 class="left"><span>СОСТАВЬ СЕБЕ ВКУСНОЕ МЕНЮ</span></h2>
            <p id="online"><b>Онлайн-конструктор рациона</b> с индивидуальной
            калорийностью рецептов</p>
       
            <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <img src="../img/meal.png" class="card-img-top" alt="Meal">
                        <div class="card-body">
                            <h5 class="card-title">Составьте свое меню</h5>
                            
                            <p class="card-text">Используйте наш конструктор для создания рациона на неделю.</p>
                            <a href="/menu" class="btn custom-green-btn">Создать меню</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <img src="../img/receips.png" class="card-img-top" alt="Recipes">
                        <div class="card-body">
                            <h5 class="card-title">Ищите рецепты</h5>
                            <p class="card-text">Фильтруйте рецепты по любимым блюдам и находите новые идеи!</p>
                            <a href="/receips" class="btn custom-green-btn">Посмотреть рецепты</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <img src="../img/articles.png" class="card-img-top" alt="Articles">
                        <div class="card-body">
                            <h5 class="card-title">Читайте статьи</h5>
                            <p class="card-text">Научитесь большему о питании и здоровом образе жизни.</p>
                            <a href="/articles" class="btn custom-green-btn">Читать статьи</a>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <footer class="text-center my-4 footer-custom" style="color:white">
            <p>&copy; <?php echo e(date('Y')); ?> - Все права защищены. Ваше приложение для планирования питания.</p>
        </footer>
    </div>

    <!-- JS и jQuery для Bootstrap -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php /**PATH C:\OSPanel\domains\borovinskikh\easyMenu\resources\views/index.blade.php ENDPATH**/ ?>