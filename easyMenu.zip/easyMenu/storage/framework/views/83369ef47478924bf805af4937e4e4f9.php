<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Главная страница - Планирование питания</title>

    <!-- Подключение CSS Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Ваши собственные стили -->
    <link rel="stylesheet" href="../asset/css/style.css">
    <style>
        .navbar-custom {
            background-color: #D94351; /* Ваш цвет */
        }
        .navbar-custom a {
            color:white;
        }
        .footer-custom
        {
            background-color: #E43E4E; /* Ваш цвет */
        }
        .nav-link{
           color:white;
        }
        h2 {
  display: flex;
  align-items: center;
  justify-content: center;
  color:#453E50;
}
h2 span {
  background: #fff;
  margin: 0 15px;
}
h2:before,
h2:after {
  background: #AECB6F;
  height: 2px;
  flex: 1;
  content: '';
}
h2.left:after {
  background: #AECB6F;
}
h2.right:before {
  background: #AECB6F;
}
.my-4
{
    color:#453E50;
}

    </style>
       
</head>
<body>
    <div class="container">
    
    <nav class="navbar navbar-expand-lg navbar-light navbar-custom" > 
    <img src="../img/logo.svg" style="width:200px;height:200px; margin-right:100px;margin-left:20px"> 
    <a class="navbar-brand" href="/">ГЛАВНАЯ</a> 
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> 
        <span class="navbar-toggler-icon"></span> 
    </button> 
    <div class="collapse navbar-collapse" id="navbarSupportedContent"> 
        <ul class="navbar-nav mr-auto" > 
            <li class="nav-item" > 
                <a class="nav-link" href="/menu">КОНСТРУКТОР МЕНЮ</a> 
            </li> 
            <li class="nav-item"> 
                <a class="nav-link" href="../img/receips.png">РЕЦЕПТЫ</a> 
            </li> 
            <li class="nav-item"> 
                <a class="nav-link" href="../img/articles.png">СТАТЬИ</a> 
            </li> 
        </ul> 
        <ul class="navbar-nav"> 
            <?php if(Auth::check()): ?> 
                <li class="nav-item"> 
                    <a class="nav-link" href="/profile">Личный кабинет</a> 
                </li> 
                <li class="nav-item"> 
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none"> 
                        <?php echo csrf_field(); ?> 
                    </form> 
                    <a class="nav-link" href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Выход</a> 
                </li> 
            <?php else: ?> 
                <li class="nav-item"> 
                    <a class="nav-link" href="/login">Войти</a> 
                </li> 
                <li class="nav-item"> 
                    <a class="nav-link" href="/register">Регистрация</a> 
                </li> 
            <?php endif; ?> 
        </ul> 
    </div> 
</nav>

        <main class="my-4">
            <!-- <h2>Добро пожаловать!</h2> -->
            <h2 class="left"><span>СОСТАВЬ СЕБЕ ВКУСНОЕ МЕНЮ</span></h2>
            <p><b>Онлайн-конструктор рациона</b> с индивидуальной
            калорийностью рецептов</p>
            <div class="howWork">
                
</div>
            <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <img src="images/meal.jpg" class="card-img-top" alt="Meal">
                        <div class="card-body">
                            <h5 class="card-title">Составьте свое меню</h5>
                            
                            <p class="card-text">Используйте наш конструктор для создания рациона на неделю.</p>
                            <a href="/menu" class="btn btn-primary">Создать меню</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <img src="../img/receips.png" class="card-img-top" alt="Recipes">
                        <div class="card-body">
                            <h5 class="card-title">Ищите рецепты</h5>
                            <p class="card-text">Фильтруйте рецепты по любимым блюдам и находите новые идеи!</p>
                            <a href="/recipes" class="btn btn-primary">Посмотреть рецепты</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <img src="../img/articles.png" class="card-img-top" alt="Articles">
                        <div class="card-body">
                            <h5 class="card-title">Читайте статьи</h5>
                            <p class="card-text">Научитесь большему о питании и здоровом образе жизни.</p>
                            <a href="/articles" class="btn btn-primary">Читать статьи</a>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <footer class="text-center my-4 footer-custom">
            <p>&copy; <?php echo e(date('Y')); ?> - Все права защищены. Ваше приложение для планирования питания.</p>
        </footer>
    </div>

    <!-- JS и jQuery для Bootstrap -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php /**PATH C:\OSPanel\domains\borovinskikh\4course\easyMenu\resources\views/index.blade.php ENDPATH**/ ?>