<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление статьями админ</title>

    <!-- Подключение CSS Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Ваши собственные стили -->
    <link rel="stylesheet" href="../asset/css/style.css">
    <style>
        .navbar-custom {
            background-color: #E43E4E; /* Ваш цвет */
        }
        .navbar-custom a {
            color:white;
        }
        .footer-custom
        {
            background-color:#E43E4E; /* Ваш цвет */
        }
        .nav-link{
           color:white;
        }
      
        h2 {
  display: flex;
  align-items: center;
  justify-content: center;
  color:#453E50;
}
h2 span {
  background: #fff;
  margin: 0 15px;
}
h2:before,
h2:after {
  background: #AECB6F;
  height: 2px;
  flex: 1;
  content: '';
}
h2.left:after {
  background: #AECB6F;
}
h2.right:before {
  background: #AECB6F;
}
.my-4
{
    color:#453E50;
}
.my-4 #online{
    text-align:center;
}
.navbar-brand
{
    color:white;
}

.custom-green-btn{
    background-color: #AECB6F;
    color:white;
}
a:link {color:white !important;}
a:hover {color:#453E50 !important;}
a:visited {color:white !important;}
.nav-item img{
    width:40px;
    height:40px;
    margin-right:30px;
}
    </style>
</head>
<body>
<div class="container">
    <nav class="navbar navbar-expand-lg navbar-light navbar-custom " > 
        <a href="<?php echo e(route('admin.dashboard')); ?>"><img src="<?php echo e(asset('img/logo.svg')); ?>" style="width:200px;height:200px; margin-right:100px;margin-left:20px"> </a>
    
    <a class="navbar-brand"  href="<?php echo e(route('admin.dashboard')); ?>">ГЛАВНАЯ</a> 
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> 
        <span class="navbar-toggler-icon"></span> 
    </button> 
    <div class="collapse navbar-collapse" id="navbarSupportedContent"> 
        <ul class="navbar-nav mr-auto" > 

            <li class="nav-item"> 
                <a class="nav-link" href="/admin/recipes">УПРАВЛЕНИЕ РЕЦЕПТАМИ</a> 
            </li> 
            <li class="nav-item"> 
                <a class="nav-link" href="/admin/articles">УПРАВЛЕНИЕ СТАТЬЯМИ</a> 
            </li> 
        </ul> 
        <ul class="navbar-nav"> 
            <?php if(Auth::check()): ?> 
  
                <li class="nav-item"> 
                    <a class="nav-link" href="/profile"><img src="../img/user.png"> </a> 
                </li> 
                <li class="nav-item"> 
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none"> 
                        <?php echo csrf_field(); ?> 
                    </form> 
                    <a class="nav-link" href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Выход</a> 
                </li> 
            <?php else: ?> 
                <li class="nav-item"> 
                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><img  src="../img/user.png"> </a> 

                </li> 
                <!-- <li class="nav-item"> 
                    <a class="nav-link" href="/register">Регистрация</a> 
                </li>  -->
            <?php endif; ?> 
        </ul> 
    </div> 
</nav>
<h1>Список статей</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <a href="<?php echo e(route('admin.createArticle')); ?>" class="btn btn-primary">Добавить статью</a>

    <table class="table">
        <thead>
            <tr>
                <th>Изображение</th>
                <th>Заголовок</th>
                <th>Содержимое</th>
                <th>Действия</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php if($post->image): ?>
                        <img src="<?php echo e(asset('img/' . $post->image)); ?>" style="width:200px;height:200px" alt="Image">
                        <?php else: ?>
                            <span>Нет изображения</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($post->title); ?></td>
                    <td><?php echo e(Str::limit($post->content, 50)); ?> <a href="<?php echo e(route('admin.editArticle', $post->post_id)); ?>">Читать далее</a></td>
                    <td>
                        <a href="<?php echo e(route('admin.editArticle', $post->post_id)); ?>" class="btn btn-warning">Редактировать</a>
                        <form action="<?php echo e(route('admin.destroyArticle', $post->post_id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Удалить</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>



        <footer class="text-center my-4 footer-custom" style="color:white">
            <p>&copy; <?php echo e(date('Y')); ?> - Все права защищены. Ваше приложение для планирования питания.</p>
        </footer>
    </div>

    <!-- JS и jQuery для Bootstrap -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php /**PATH C:\OSPanel\domains\borovinskikh\easyMenu\resources\views/admin/articlesAdmin.blade.php ENDPATH**/ ?>